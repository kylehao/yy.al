window._CCSettings = {
    platform: "web-mobile",
    groupList: ["default", "move", "UI", "fish"],
    collisionMatrix: [
        [true, true, true, true],
        [true, true, null, true],
        [true, false, false],
        [true, true, false, false]
    ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/Scene/MainGameScene.fire",
    orientation: "portrait",
    jsList: [],
    bundleVers: {
        internal: "803f8",
        resources: "93f29",
        main: "3786c"
    }
};